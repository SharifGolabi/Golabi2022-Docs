# include<bits/stdc++.h>

using namespace std;

const int N = 10;
int a[N][N] , cnt_row[N] , cnt_col[N] , cnt_square[N];
vector < vector < int > > b;
set < vector < vector < int > > > s;
bool is_valid() {
    for(int i = 1;i < N;++ i)
        for(int j = 1;j < N;++ j) {
            if(b[i][j] < 1 || b[i][j] > 9) return false;
            if(a[i][j] != 0 && b[i][j] != a[i][j]) return false;
        }
    for(int i = 1;i < N;++ i) {
        memset(cnt_row , 0 , sizeof cnt_row);
        memset(cnt_col , 0 , sizeof cnt_col);
        memset(cnt_square , 0 , sizeof cnt_square);
        for(int j = 1;j < N;++ j) {
            cnt_row[b[i][j]] ++;
            cnt_col[b[j][i]] ++;
        }
        int l = ((i - 1) / 3) * 3 + 1;
        int r = ((i - 1) % 3) * 3 + 1;
        for(int x = l;x < l + 3;++ x)
            for(int y = r;y < r + 3;++ y)
                ++ cnt_square[b[x][y]];

        for(int j = 1;j < N;++ j)
            if(cnt_row[j] != 1 || cnt_col[j] != 1 || cnt_square[j] != 1)
                return false;
    }
    return true;
}
int main(int argc, char const *argv[]) {

	ifstream test_in(argv[1]);
    ifstream test_out(argv[2]);
	ifstream user_out(argv[3]);
    b.resize(N , vector < int >(N));
	for(int i = 1;i < N;++ i)
        for(int j = 1;j < N;++ j)
            test_in >> a[i][j];
    int need , user_cnt;
    test_out >> need;
    user_out >> user_cnt;
    if(user_cnt < need) return 1;
    for(int _ = 0;_ < need;++ _) {
        for(int i = 1;i < N;++ i) {
            for(int j = 1;j < N;++ j) {
                user_out >> b[i][j];
                if(j == 3 || j == 6) {
                    char dummy;
                    user_out >> dummy;
                }
            }
            if(i == 3 || i == 6) {
                char dummy;
                for(int j = 1;j <= 22;++ j)
                    user_out >> dummy;
            }
        }
        if(! is_valid())
            return 1;
        s.insert(b);
    }
    if(s.size() < need)
        return 1;
    return 0;
}

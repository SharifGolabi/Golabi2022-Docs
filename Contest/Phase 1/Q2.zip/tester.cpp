# include<bits/stdc++.h>

using namespace std;

const int N = 1077;
int n , m , t , s , out[N] , a[N] , b[N] , c[N];
int main(int argc, char const *argv[]) {

	ifstream test_in(argv[1]);
	ifstream user_out(argv[3]);
    test_in >> n >> m >> t;
    for(int i = 1;i <= n;++ i)
        test_in >> a[i];
    for(int i = 1;i <= m;++ i)
        test_in >> b[i];
    for(int i = 1;i <= n;++ i) {
        user_out >> out[i];
        if(out[i] < 1 || out[i] > m)
            continue ;
        s ++;
        c[out[i]] += a[i];
    }
    if(s < t) return 1;
    for(int i = 1;i <= m;++ i)
        if(c[i] > b[i])
            return 1;
    return 0;
}

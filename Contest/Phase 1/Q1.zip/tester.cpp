//
// Created by Naser Kazemi on 11/25/2021 AD.
//

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(int argc, char const *argv[]) {

    ifstream test_in(argv[1]);    /* This stream reads from test's input file   */
    ifstream test_out(argv[2]);   /* This stream reads from test's output file  */
    ifstream user_out(argv[3]);   /* This stream reads from user's output file  */

    /* Your code here */
    /* If user's output is correct, return 0, otherwise return 1       */

    int N;
    test_in >> N;
    long long C, vol[N], correct_ans[N], user_ans[N];
    test_in >> C;
    for (int i = 0; i < N; i++)
        test_in >> vol[i];

    string test_output_string;
    if (test_out.good()) // if test's output file exists
    {
        test_out >> test_output_string;
        if (test_output_string == "IMPOSSIBLE") {
            string user_output_string;
            user_out >> user_output_string;
            if (user_output_string == "IMPOSSIBLE")
                return 0;
            return 1;
        }
        correct_ans[0] = stoi(test_output_string);
        for (int i = 1; i < N; i++)
            test_out >> correct_ans[i];
        for (int i = 0; i < N; i++)
            user_out >> user_ans[i];
        sort(vol, vol + N, [&](int x, int y) { return x < y; });
        if (user_ans[N - 1] != correct_ans[N - 1])
            return 1;
        for (int i = 0; i < N; i++)
            if (user_ans[i] > vol[i])
                return 1;
    }
    return 0;


}